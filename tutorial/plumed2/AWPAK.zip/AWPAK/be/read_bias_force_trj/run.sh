python3.8 ../../../../../calcf_vgauss.py -if input.dat -units kj -temp 300 > job&

python3.8 ../../../../../graf_fes_kmc.py -ff grad_on_eff_points.out -units kj -temp 2300 -nsteps 10000000000 -weth 1 -ofesf fes.out

# read force components

fgrep -v \# ../forces.0 | awk '{print $1,$2}' > forces_comp.0

fgrep -v \# ../forces.1 | awk '{print $1,$3}' > forces_comp.1

python3.8 /home/marinellif/PROG/FCAM/calcf_vgauss.py -if input_comp.dat -units kj -temp 300 > job&


# evaluate error from first and second block

python3.8 ../../../../../graf_fes_kmc.py -ff grad_on_eff_points1.out -units kj -temp 2300 -nsteps 10000000000 -weth 1 -ofesf fes1.out

python3.8 ../../../../../graf_fes_kmc.py -ff grad_on_eff_points2.out -units kj -temp 2300 -nsteps 10000000000 -weth 1 -ofesf fes2.out

