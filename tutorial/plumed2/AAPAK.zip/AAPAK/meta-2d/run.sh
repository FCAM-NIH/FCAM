python3.8 ../../../../calcf_vgauss.py -if input.dat -units kj -temp 300 -colv_time_prec 2 > job&

python3.8 ../../../../graf_fes_kmc.py -ff grad_on_eff_points.out -units kj -temp 2300 -nsteps 100000000000 -weth 1 -ofesf fes_100000000000.out

#long kmc

python3.8 ../../../../graf_fes_kmc.py -ff grad_on_eff_points.out -units kj -temp 2300 -nsteps 100000000000 -weth 1 -ofesf fes_100000000000.out


# reverse finite differences

python3.8 ../../../../graf_fes_kmc.py -ff grad_on_eff_points.out -rfd -units kj -temp 2300 -nsteps 100000000 -weth 1 -ofesf fes_rfd.out > job_rfd

# evaluate error from first and second block

python3.8 ../../../../graf_fes_kmc.py -ff grad_on_eff_points1.out -units kj -temp 2300 -nsteps 10000000000 -weth 1 -ofesf fes1.out

python3.8 ../../../../graf_fes_kmc.py -ff grad_on_eff_points2.out -units kj -temp 2300 -nsteps 10000000000 -weth 1 -ofesf fes2.out

