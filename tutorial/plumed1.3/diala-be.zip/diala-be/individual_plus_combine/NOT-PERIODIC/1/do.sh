dirs=`echo READ_BIAS_COMP/ READ_BIAS_COMP2/ READ_BIAS_COMP2_dict/ READ_BIAS_COMP_dict/ READ_BIAS_COMP_inv/ READ_BIAS_COMP_inv_dict/ READ_GRAD/ READ_GRAD_NEW/`
for i in $dirs ; do mkdir $i ; done
for i in $dirs ; do cp ../../1/${i}/input.dat ../../1/${i}/run.sh ../../1/$i/check_error.sh ${i}/ ; done
for i in $dirs ; do pushd ${i} ; sed "s/PERIODIC//g" input.dat > pippo ; mv pippo input.dat ; popd; done
for i in $dirs ; do pushd ${i} ; sed "s/ \.\.\// \.\.\/\.\.\//g" input.dat > pippo ; mv pippo input.dat ; popd; done
for i in $dirs ; do pushd ${i} ; sed "s/\.\.\/bias/bias/g" input.dat > pippo ; mv pippo input.dat ; popd; done
# select biased component of biasing force
fgrep -v \# bias_grad.out | awk '{print $1,$2}' > bias_grad_comp.out

# invert biased component of biasing force
fgrep -v \# bias_grad.out | awk '{print $1,$3,$2}' > bias_grad_inv.out

for i in $dirs ; do pushd ${i} ; bash run.sh ; popd ; done

for i in $dirs ; do cd ${i} ; bash check_error.sh ; cd .. ; done
