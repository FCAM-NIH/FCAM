python3.8 /data/TMB-CSB/Marinelli/PROG/FCAM/calcf_vgauss.py -if input.dat -units kj -temp 298 > job&
