python3.8 ../../../../../calcf_vgauss.py -if input.dat -units kj -temp 298  > job&

