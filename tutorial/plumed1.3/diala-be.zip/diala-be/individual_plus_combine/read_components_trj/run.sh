# read components

python3.8 /home/marinellif/PROG/FCAM/calcf_vgauss.py -if input_read_force_traj.dat -units kj -temp 298 > job&

python3.8 /home/marinellif/PROG/FCAM/calcf_vgauss.py -if input_read_force_traj_dict.dat -units kj -temp 298 -oeff grad_on_eff_points_dict.out > job_dict&

