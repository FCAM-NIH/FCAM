# read components

python3.8 /data/TMB-CSB/Marinelli/PROG/FCAM/calcf_vgauss.py -if input_read_force_traj_def.dat -units kj -temp 298 -oeff grad_on_eff_points_def.out > job_def&

