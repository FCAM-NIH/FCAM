python3.8 /home/marinellif/PROG/FCAM/calcf_vgauss.py -if input.dat -units kj -temp 298 > job&

