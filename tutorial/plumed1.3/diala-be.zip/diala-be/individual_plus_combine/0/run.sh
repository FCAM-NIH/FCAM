python3.8 /data/TMB-CSB/Marinelli/PROG/FCAM/calcf_vgauss.py -if input.dat -units kj -temp 298 > job&

# select biased component of biasing force
fgrep -v \# bias_grad.out | awk '{print $1,$3}' > bias_grad_comp.out

# invert biased component of biasing force
fgrep -v \# bias_grad.out | awk '{print $1,$3,$2}' > bias_grad_inv.out
	


