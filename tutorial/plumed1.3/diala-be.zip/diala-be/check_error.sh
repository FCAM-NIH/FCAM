tol=0.0000000001
paste eff_points.out results/eff_points.out | fgrep -v \# | awk -v tol=$tol 'BEGIN{good=1}{err=sqrt(($2-$6)*($2-$6)+($3-$7)*($3-$7)); if(err>tol){good=0}}END{if(good==0){print "NOT PASSED"};if(good==1){print "PASSED"}}'
paste bias_grad.out results/bias_grad.out | fgrep -v \# | awk -v tol=$tol 'BEGIN{good=1}{err=sqrt(($2-$10)*($2-$10)+($3-$11)*($3-$11)); if(err>tol){good=0}}END{if(good==0){print "NOT PASSED"};if(good==1){print "PASSED"}}'
paste grad_on_eff_points.out results/grad_on_eff_points.out | fgrep -v \# | awk -v tol=$tol 'BEGIN{good=1}{err=sqrt(($3-$8)*($3-$8)+($4-$9)*($4-$9)+($5-$10)*($5-$10)); if(err>tol){good=0}}END{if(good==0){print "NOT PASSED"};if(good==1){print "PASSED"}}'

